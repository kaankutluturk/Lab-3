# Results

> Fill this after running theHarvester.

## Commands used

```bash
# example
theHarvester -d beuth-hochschule.de -b all -l 200 -f beuth-hochschule
```

## Summary

- Emails found: 
- Hosts/subdomains found: 
- Notes:

## Sample findings (redact if needed)

- 
