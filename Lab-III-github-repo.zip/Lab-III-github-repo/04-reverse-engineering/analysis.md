# RE / Decompile analysis

> Fill this after decompiling.

## Build log

```bash
gcc -o test test.c
```

## Decompiler output

(Recovered pseudocode)
