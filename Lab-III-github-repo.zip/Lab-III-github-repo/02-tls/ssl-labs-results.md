# SSL Labs results

> Fill this after running the SSL Labs test.

- Hostname tested:
- Date/time:
- Grade:

## Key findings

### What was good
- 

### What needs improvement
- 

### Remediation ideas
- 
